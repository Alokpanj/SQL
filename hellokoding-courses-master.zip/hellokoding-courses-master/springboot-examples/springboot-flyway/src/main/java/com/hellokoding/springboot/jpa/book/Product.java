package com.hellokoding.springboot.jpa.book;

import lombok.Value;

@Value
public class Product {
    private Integer id;
    private String name;
}
