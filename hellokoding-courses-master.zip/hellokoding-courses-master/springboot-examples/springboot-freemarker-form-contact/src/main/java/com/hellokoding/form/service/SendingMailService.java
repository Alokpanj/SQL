package com.hellokoding.form.service;

public interface SendingMailService {
    boolean sendMail(String subject, String body);
}
